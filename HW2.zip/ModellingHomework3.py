#!/usr/bin/env python
# coding: utf-8

# In[226]:


import matplotlib.pyplot as plt
import networkx as nx
import pandas as pd
import numpy as np
import random
import math
from statistics import mean as average
import seaborn as sns
from scipy import stats
import scipy


# In[248]:


Is=[]
Rs=[]
Ss=[]
indices=[]
initial_number_of_infection=10
accuracy=1
while(accuracy <=1000):
    indices.append(accuracy)
    G = nx.Graph()
    list =[]
    att= ['S']
    for i in range(0 ,256):
            list.append(i+1)
    for i in range(0 ,256):
            G.add_nodes_from(list)
    nx.set_node_attributes(G, values={'S'}, name='condition')
    nx.set_node_attributes(G, values={'$'}, name='futureCondition')
    for i in range(0 , 16):
        for j in range(0 ,16):
            G.add_edge(16*i+(j%16)+1 ,16*i+((j+1)%16)+1)
    for i in range(0 , 16):
        for j in range(0 ,16):
            G.add_edge(16*i+(j)+1 ,16*((i+1)%16)+(j)+1)
#I = 0.2 = 0.2 *256 =51
    d=1
    while d<=initial_number_of_infection:
        k = random.choice(list)
        if(G.node[k]['condition']!='I'):
            G.node[k]['condition']='I'
            d+=1
#probability for recovery =0.2 qnd probability for infection is 0.3
    Inum=2000
    gamma = 0.05
    Rnum=0
    beta =0.1
    while(Inum>0):
        Inodes =[x for x ,y in G.nodes(data=True) if y['condition']=='I']
        Inum=len (Inodes)
        rec=[]
        for f in Inodes:
            if(random.random()<gamma):
                rec.append(f) 
        if(len(rec)>0):
            for i in rec:
                G.node[i]['futureCondition']='R'    
        for i in Inodes:
            neighborsList =[n for n in G.neighbors(i)]
            neighborSample =[]
            for f in neighborsList:
                if(random.random()<beta):
                        neighborSample.append(f) 
            if(len(neighborSample)>0):
                for j in neighborSample:
                    if  G.node[j]['condition']=={'S'} :
                        G.node[j]['futureCondition']='I'
        afterR=[x for x ,y in G.nodes(data=True) if y['futureCondition']=='R']
        afterI=[x for x ,y in G.nodes(data=True) if y['futureCondition']=='I']
        for i in afterI:
            G.node[i]['condition']='I'
            G.node[i]['futureCondition']='$'
            Inum+=1
        for i in afterR:
            G.node[i]['condition']='R'
            G.node[i]['futureCondition']='$'
            Rnum+=1
            Inum-=1
    Snum=256-(Inum+Rnum)
    accuracy+=1
    
    Is.append(Inum/256)
    Rs.append(Rnum/256)
    Ss.append(Snum/256)


# In[249]:


plt.plot(indices , Rs )
plt.title("Network based SIR model \"R\" proportion")
plt.xlabel("number of experiment")
plt.ylabel(" R Group population proportion")
x = np.linspace(0 , 1000)
y = average(Rs)*(x+1) - average(Rs)*x 
plt.plot(x , y )
print(average(Rs))
plt.legend(['R', 'Average'], shadow=True)
#plt.text(170, 0.8, ' average(R)=0.8385' )
plt.show()


# In[ ]:





# In[253]:


data = []
good_data = []
minRs =min(Rs)
maxRs = max(Rs)
span = maxRs - minRs
bins = 31
part = span /bins
parts =[[i*part , (i+1)*part,0] for i in range (bins)]
for data_point in Rs:
    bin_number =math.floor( data_point//part)
    if bin_number>=bins:
        bin_number=30
    parts[bin_number][2]+=1
for i in  range (0 , len(parts)-1):
    data.append((parts[i][0]+parts[i][1])/2)
    good_data.append(parts[i][2]/1000)


# In[251]:


def func( x,a, b ):
    data2=[]
    for i in range (0 , len(x)):
        data2.append(b*x[i])
    return a*np.exp(data2)
popt , pcov=scipy.optimize.curve_fit(lambda t,a,b: a*np.exp(b*t), data , good_data)
model =func(data ,popt[0] , popt[1])
abserr = model -good_data

SE=np.square(abserr)
MSE=np.mean(SE)
RMSE=np.sqrt(MSE)
rsquared = np.sqrt(1-(np.var(abserr)/np.var(good_data)))
RMSE


# In[252]:


plt.plot(data , good_data)
plt.title("R\u221E distribution p=0.7 , r=1")
plt.xlabel("R \u221E proportion")
plt.ylabel("frequency")
plt.savefig("hello.png")


# In[197]:


good_data


# In[ ]:





# In[256]:


n , bins ,patches = plt.hist(Rs , 30, alpha = 0.98 , histtype='bar')
plt.title("R\u221E histogram p=0.7 , r=1")
plt.xlabel("R\u221E proportion")
plt.ylabel("frequency")


# In[298]:


overallR=[]
overallR2=[]


# In[314]:


overallR3=[]


# In[ ]:


Ratios=[]
npdata =np.arange(0,0.04 , 0.0004)
print(npdata)
gamma = 0.01
for i in  range (0,100):

    beta =npdata[i]
    indices=[]
    initial_number_of_infection=100
    accuracy=1
    while(accuracy <=100):
        indices.append(accuracy)
        G = nx.Graph()
        list =[]
        att= ['S']
        for i in range(0 ,256):
                list.append(i+1)
        for i in range(0 ,256):
                G.add_nodes_from(list)
        nx.set_node_attributes(G, values={'S'}, name='condition')
        nx.set_node_attributes(G, values={'$'}, name='futureCondition')
        for i in range(0 , 16):
            for j in range(0 ,16):
                G.add_edge(16*i+(j%16)+1 ,16*i+((j+1)%16)+1)
        for i in range(0 , 16):
            for j in range(0 ,16):
                G.add_edge(16*i+(j)+1 ,16*((i+1)%16)+(j)+1)
#I = 0.2 = 0.2 *256 =51
        d=1
        while d<=initial_number_of_infection:
            k = random.choice(list)
            if(G.node[k]['condition']!='I'):
                G.node[k]['condition']='I'
                d+=1
#probability for recovery =0.2 qnd probability for infection is 0.3
        Inum=2000
        Rnum=0
        while(Inum>1):
            Inodes =[x for x ,y in G.nodes(data=True) if y['condition']=='I']
            Inum=len (Inodes)
            rec=[]
            for f in Inodes:
                if(random.random()<gamma):
                    rec.append(f) 
            if(len(rec)>0):
                for i in rec:
                    G.node[i]['futureCondition']='R'    
            for i in Inodes:
                neighborsList =[n for n in G.neighbors(i)]
                neighborSample =[]
                for f in neighborsList:
                    if(random.random()<beta):
                            neighborSample.append(f) 
                if(len(neighborSample)>0):
                    for j in neighborSample:
                        if  G.node[j]['condition']=={'S'} :
                            G.node[j]['futureCondition']='I'
            afterR=[x for x ,y in G.nodes(data=True) if y['futureCondition']=='R']
            afterI=[x for x ,y in G.nodes(data=True) if y['futureCondition']=='I']
            for i in afterI:
                G.node[i]['condition']='I'
                G.node[i]['futureCondition']='$'
                Inum+=1
            for i in afterR:
                G.node[i]['condition']='R'
                G.node[i]['futureCondition']='$'
                Rnum+=1
                Inum-=1
        accuracy+=1
        Ratios.append(beta/gamma)
        overallR3.append(Rnum/256)
    


# In[313]:


plt.plot(Ratios , overallR2 , 'o' , color = 'aqua' , alpha = 0.10 ,label='I=1' )
plt.plot(Ratios , overallR , 'o' , color = 'pink' , alpha = 0.10  ,label='I=10' )
plt.plot(Ratios , overallR3 , 'o' , color = 'purple' , alpha = 0.10  ,label='I=100' )
plt.legend(shadow=True)
plt.plot
plt.xlabel("Ratio")
plt.title("R\u221E distribution")
plt.ylabel(" R\u221E Group population proportion")


# In[305]:


print(overallR)


# In[219]:


import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import random

#creating graph
G = nx.Graph()
G.add_nodes_from(range(256))

#add_edge
for i in range(300):
    j = i % 256
    G.add_edge(j, (j + 16))
    G.add_edge(j, (j + 1))
print(G.edges(1))
#add attribute
nx.set_node_attributes(G, values = {'S'}, name = 'condition')
nx.set_node_attributes(G, values = {'S'}, name = 'future')

#one person, number 100, get sick!
G.nodes[100]['condition'] = 'I'

#probability of spreading
p = 0.3
#1000 time steps
t = np.arange(0,1000,1)


for i in range(1000):
    #future conditions
    #Inodes = [x for x, y in G.nodes(data = True) if y['condition'] == 'I']
    for j in range(256):
        if G.nodes[j]['condition'] == {'I'}:
            G.nodes[j]['future'] = 'R'
            neighbors = list(G.neighbors(j))
            for k in neighbors:
                if G.nodes[k]['condition'] == {'I'}:
                    G.nodes[k]['future'] = 'R'
                else:
                    if random.random() < p:
                        G.nodes[k]['future'] = 'I'
                    else:
                        G.nodes[k]['future'] = 'S'
    #conditions
    for l in range(256):
        G.nodes[l]['condition'] = G.nodes[l]['future']


finalRnodes = 0
for m in range(256):
    if G.nodes[m]['condition'] == {'R'}:
        finalRnodes += 1

