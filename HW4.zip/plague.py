#!/usr/bin/env python
# coding: utf-8

# In[45]:


import pandas as pnd
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
from scipy import asarray as ar , exp
import statistics as st


# In[3]:


month=[]
for i in range(0 ,52):
            month.append(i+1)
month = ar(month)


# In[2]:


death=ar([12, 16 ,24 , 48 , 51 , 92 , 124, 178 , 280 , 387 , 442 , 644 , 779 , 702 , 695 , 870 , 925, 802 ,578,404 ,296,162,106,64,46,35,27,28,24,26,29,17,31,15,14 , 18,22,22,30,31,18,12,9,13,6,9,5,9,16,8,8,10])


# In[16]:


#plague={'month':month ,'death':death}
#df = pnd.DataFrame(plague, columns=['month', 'death'])
#df.to_csv(r'C:\Users\asus\Desktop\Universite\Term4\plagueData.CSV', index = False)


# In[38]:


n = len(month)
mean=sum(month*death)/sum(death)
sigma = np.sqrt(sum(death*(month-mean)**2)/sum(death))


# In[37]:


def guass(x , a, x0 ,sigma):
    return a*exp(-(x-x0)**2/(2*sigma**2))
popt , pcov = curve_fit(guass ,month , death , p0=[max(death) , mean , sigma])


# In[52]:


popt


# In[23]:


plt.plot(month , death ,'x' , color = 'blue'  , label='data')
plt.plot(month , guass(month , *popt) , color ='violet' , label ='guassian fit')
plt.legend(shadow = True)
plt.ylabel('Plague Incidence')
plt.xlabel('time(week)')
plt.title('Plague outbreak bombay 1905')
plt.show()


# In[31]:


def bookFunction(x , a, b, c):
    return a*(1/(np.cosh(b*x-c)))**2
popt1 , pcov1 = curve_fit(bookFunction ,month , death )
plt.plot(month , death ,'x' , color = 'red'  , label='data')
plt.plot(month , bookFunction(month , *popt1) , color ='orange' , label ='book function fit')
plt.legend(shadow=True)
plt.ylabel('Plague Incidence')
plt.xlabel('time(week)')
plt.title('Plague outbreak bombay 1905')
plt.show()


# In[47]:


y = bookFunction(month , *popt1)-death
print(np.sqrt(np.var(y)))


# In[46]:


y = guass(month , *popt)-death
print(st.stdev(y))


# In[48]:


pcov

