#!/usr/bin/env python
# coding: utf-8

# In[3]:


import pandas as pnd
import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp as ODESolver


# In[4]:


def  SIS(t, Components):
    return [-(beta*Components[0]*Components[1])+(gamma*Components[1]),(beta*Components[0]*Components[1])-(gamma*Components[1])]


# In[5]:


def SISSolve(beta , gamma , I):
    S=1-I
    Input = (S,I)
    start_t=0.
    end_t=100*365
    t_inc=1.0
    t_range=np.arange(start_t , end_t+t_inc , t_inc)

    ODEAnswer = ODESolver(SIS, t_range, [S , I ])

    return [ODEAnswer[:,0],ODEAnswer[:,1]]
#beta =520/(365*2)
#gamma=2*gamma
#ODEAnswer2 = spi.odeint(SIRBirthIncluded,Input ,t_range)
#beta =2*520/365
#gamma=gamma/9
#ODEAnswer3 = spi.odeint(SIRBirthIncluded,Input ,t_range)


# In[6]:


I=0.1
S=1-I
beta=0.001
gamma=0.002
ODEAnswer = ODESolver(SIS, (0,18000), [S , I ],'LSODA')
plt.plot(ODEAnswer.t, ODEAnswer.y.T[:,1], label='\u03B2 =0.001')
beta=0.002
ODEAnswer = ODESolver(SIS, (0,18000), [S , I ],'LSODA')
plt.plot(ODEAnswer.t, ODEAnswer.y.T[:,1], label='\u03B2 =0.002')
beta=0.00225
ODEAnswer = ODESolver(SIS, (0,18000), [S , I ],'LSODA')
plt.plot(ODEAnswer.t, ODEAnswer.y.T[:,1], label='\u03B2 =0.00225')
beta=0.003
ODEAnswer = ODESolver(SIS, (0,18000), [S , I ],'LSODA')
plt.plot(ODEAnswer.t, ODEAnswer.y.T[:,1], label='\u03B2 =0.003')
beta=0.004
ODEAnswer = ODESolver(SIS, (0,18000), [S , I ],'LSODA')
plt.plot(ODEAnswer.t, ODEAnswer.y.T[:,1], label='\u03B2 =0.004')
beta=0.005
ODEAnswer = ODESolver(SIS, (0,18000), [S , I ],'LSODA')
plt.plot(ODEAnswer.t, ODEAnswer.y.T[:,1], label='\u03B2 =0.005')
plt.legend(shadow=True)
plt.title('SIS model I =0.1 \u03B3 =0.002')
plt.ylabel(' I Group population')
plt.xlabel('time(unit)')
plt.xlim(0,17500)
plt.ylim(0)
plt.show()


# In[108]:


Ans1=SISSolve(0.05 , 0.002, 0.9)
#Ans2=SISSolve(0.003 , 0.002, 0.9)[1]
#Ans3=SISSolve(0.0008 , 0.002, 0.9)[1]
#Ans4=SISSolve(0.003 , 0.002, 0.9)[1]
#Ans5=SISSolve(0.003 , 0.002, 1/3)[1]
#plt.plot(Ans1 , label='I=0.0009')
#plt.plot(Ans2 , label='I=0.009')
#plt.plot(Ans3 , label='I=0.09')
#plt.plot(Ans4 , label='I=0.9')
#plt.plot(Ans5 , label='I=1/3')
#plt.plot(Ans1[0] , label='S')
#plt.plot(Ans1[1] , label='I')
plt.legend(shadow=True)
plt.grid()
plt.title('SIS model \u03B3 =0.001 \u03B2 =0.003')
plt.ylabel('Group population')
plt.xlabel('time(unit)')
plt.show()


# In[184]:


I=0.2
S=1-I
beta=0.005
gamma=0.002
ODEAnswer = ODESolver(SIS, (0,18000), [S , I ],'LSODA')
plt.plot(ODEAnswer.t, ODEAnswer.y.T[:,0], label='S' ,color= 'blue')
plt.plot(ODEAnswer.t, ODEAnswer.y.T[:,1], label='I',color='red')
plt.title('SIS model \u03B3 =0.002 \u03B2 =0.005 I=0.2')
plt.xlim(0,10000)
plt.ylim(0)
plt.ylabel('Group population')
plt.xlabel('time(unit)')


# In[27]:


npdata =np.arange(0,0.01 , 0.0001)
Is=[]
ratios=[]
for i in npdata:
    beta=i
    gamma=0.002
    I=0.2
    S=1-I
    ODEAnswer = ODESolver(SIS, (0,30000), [S , I],'LSODA')
    Is.append(ODEAnswer.y.T[-1][1])
    ratios.append(i/gamma)


# In[30]:


plt.plot(ratios,Is, color='blue' )
plt.title('Phase diagram')
plt.xlabel('R0')
plt.ylabel('I\u221E population')

