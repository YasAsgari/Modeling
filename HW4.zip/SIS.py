#!/usr/bin/env python
# coding: utf-8

# In[2]:


import matplotlib.pyplot as plt
import networkx as nx
import pandas as pd
import numpy as np
import random
import math
from statistics import mean as average
import seaborn as sns
from scipy import stats
import scipy


# In[57]:


def hello(i):
    print('hello')
    return i


# In[58]:


hello(1)


# In[63]:


def GraphPrepration(infection , N):
    G = nx.Graph()
    list =[]
    for i in range(0 ,N*N):
            list.append(i+1)
    for i in range(0 ,N*N):
            G.add_nodes_from(list)
    nx.set_node_attributes(G, values={'S'}, name='condition')
    nx.set_node_attributes(G, values={'$'}, name='futureCondition')
    for i in range(0 ,N):
        for j in range(0 ,N):
            G.add_edge(N*i+(j%N)+1 ,N*i+((j+1)%N)+1)
    for i in range(0 , N):
        for j in range(0 ,N):
            G.add_edge(N*i+(j)+1 ,N*((i+1)%N)+(j)+1)
    d=1
    while d<=infection:
        k = random.choice(list)
        if(G.node[k]['condition']!='I'):
            G.node[k]['condition']='I'
            d+=1
    for i in G.nodes():
        if(G.node[k]['condition']!='I'):
            G.node[k]['condition']='S
    Inodes =[x for x ,y in G.nodes(data=True) if y['condition']=='S']
    
    return G


# In[70]:


GraphPrepration(1 , 4)


# In[267]:


def SISSolve(beta , gamma , infection , N):
    Is=[]
    Ss=[]
    ThresholdList=[]
    accuracy=1
    while(accuracy <=300):
        G = nx.Graph()
        koft=1
        list =[]
        for i in range(0 ,N*N):
                list.append(i+1)
        for i in range(0 ,N*N):
                G.add_nodes_from(list)
        nx.set_node_attributes(G, values={'S'}, name='condition')
        nx.set_node_attributes(G, values={'$'}, name='futureCondition')
        for i in range(0 ,N):
            for j in range(0 ,N):
                G.add_edge(N*i+(j%N)+1 ,N*i+((j+1)%N)+1)
        for i in range(0 , N):
            for j in range(0 ,N):
                G.add_edge(N*i+(j)+1 ,N*((i+1)%N)+(j)+1)
        d=1
        while d<=infection:
            k = random.choice(list)
            if(G.node[k]['condition']!='I'):
                G.node[k]['condition']='I'
                d+=1
        for i in G.nodes():
            if(G.node[i]['condition']!='I'):
                G.node[i]['condition']='S'   
        while(True):
            Inodes =[x for x ,y in G.nodes(data=True) if y['condition']=='I']
            rec=[]
            for f in Inodes:
                if(random.random()<gamma):
                    rec.append(f) 
            if(len(rec)>0):
                for i in rec:
                    G.node[i]['futureCondition']='S'   
            for i in Inodes:
                neighborsList =[n for n in G.neighbors(i)]
                Ssample=[]
                for k in neighborsList:
                     if  G.node[k]['condition']=='S' :
                        Ssample.append(k)  
                neighborSample =[]
                if(len(Ssample)>0):
                    for f in Ssample:
                        if(random.random()<beta):
                            neighborSample.append(f)      
                    for j in neighborSample:
                        G.node[j]['futureCondition']='I'
            
            afterS=[x for x ,y in G.nodes(data=True) if y['futureCondition']=='S']
            afterI=[x for x ,y in G.nodes(data=True) if y['futureCondition']=='I']
            for i in afterI:
                G.node[i]['condition']='I'
                G.node[i]['futureCondition']='$'
            for i in afterS:
                G.node[i]['condition']='S'
                G.node[i]['futureCondition']='$'
            Inodes =[x for x ,y in G.nodes(data=True) if y['condition']=='I']
            Inum=len (Inodes)
            ThresholdList.append(Inum)
            koft+=1
            if len(ThresholdList)>3:
                ThresholdList.pop(0)
                if np.var( ThresholdList)<1:
                    Is.append(int(average(ThresholdList)))
                    Ss.append(int(N**2-average(ThresholdList)))
                    break
                    
        accuracy+=1
    return [Is , Ss]
    


# In[206]:


ans1 = SISSolve(0.3, 0.5 , 1 , 16)
#ans2= SISSolve(0.4, 0.5 , 1 , 16)
ans3= SISSolve(0.5, 0.5 , 1 , 16)
#ans4= SISSolve(0.6, 0.5 , 1 , 16)
ans5= SISSolve(0.7, 0.5 , 1 , 16)


# In[223]:


ans6= SISSolve(0.5, 0.5 , 10 , 16)
ans7= SISSolve(0.5, 0.5 , 100 , 16)


# In[265]:


#n , bins ,patches = plt.hist(ans1[0], alpha = 0.68 , histtype='bar' , label='p=0.3')
#n , bins ,patches = plt.hist(ans3[0] , alpha = 0.68 , histtype='bar', label='p=0.5')
n , bins ,patches = plt.hist(ans5[0] , alpha = 0.68 , histtype='bar', label='p=0.7')
plt.title("I\u221E histogram r=0.5 I=1 ")
plt.legend(shadow=True)
plt.xlabel("I\u221E population")
plt.ylabel("frequency")


# In[161]:


plt.plot(ans[0], ans[1] , 'bo' , alpha=0.1)
plt.title('variance of list in time')
plt.ylabel('variance')
plt.xlabel('time step')
plt.show()


# In[33]:


n , bins ,patches = plt.hist(ans[0] , 10, alpha = 0.98 , histtype='bar')
plt.title("R\u221E histogram p=0.5 , r=1")
plt.xlabel("R\u221E proportion")
plt.ylabel("frequency")


# In[13]:


def QueueEnqueue(T):
    T.pop(0)
    return T


# In[11]:


def CheckVariance(T):
    res =np.var(T)
    if res<0.5:
        return True
    return False


# In[269]:


def SISVarietyOfR0(N, infection):
    Ratios=[]
    Is=[]
    Ss=[]
    npdata =np.arange(0,1 , 0.02)
    gamma = 0.5
    for i in  npdata:
        beta =i
        print(i/0.02)
        ans = SISSolve(beta , gamma , infection , N)
        Ss.append(ans[1])
        Is.append(ans[0])
        Ratios.append(beta/gamma)
    return [Is , Ss]


# In[289]:


ratios=[]
npdata =np.arange(0,1 , 0.02)
for i in npdata:
    ratios.append(i/0.5)


# In[270]:


ans =SISVarietyOfR0(16 , 10)


# In[291]:


plt.plot(ratios,ans[0],'o' , alpha=0.08, color='pink')
plt.title('network phase diagram')
plt.xlabel('p/r')
plt.ylabel('I\u221E')
plt.show()


# In[285]:




